/* eslint-disable no-unused-vars */

// Make a copy of this file and save it as config.js (in the js directory).

// Set this to the base URL of your sample server, such as 'https://your-app-name.herokuapp.com'.
// Do not include the trailing slash. See the README for more information:

const SAMPLE_SERVER_BASE_URL = 'http://YOUR-SERVER-URL';

// OR, if you have not set up a web server that runs the learning-opentok-php code,
// set these values to OpenTok API key, a valid session ID, and a token for the session.
// For test purposes, you can obtain these from https://tokbox.com/account.

const API_KEY = '47679271';
const SESSION_ID = '2_MX40NzY3OTI3MX5-MTY4ODYxMDY2MzM2NH5TRmZPU3c3V3ArVmJXakhWYjVlcFErSjZ-fn4';
const TOKEN = 'T1==cGFydG5lcl9pZD00NzY3OTI3MSZzaWc9ZDcyMzgxMjRhY2MzMDkxNDVhOTQxNmMyMDYyMGE4MWJiNDY5NmYyYzpzZXNzaW9uX2lkPTJfTVg0ME56WTNPVEkzTVg1LU1UWTRPRFl4TURZMk16TTJOSDVUUm1aUFUzYzNWM0FyVm1KWGFraFdZalZsY0ZFclNqWi1mbjQmY3JlYXRlX3RpbWU9MTY4ODYxMDY2MyZleHBpcmVfdGltZT0xNjg4Njk3MDYzJnJvbGU9cHVibGlzaGVyJm5vbmNlPTgzNTA2OSZpbml0aWFsX2xheW91dF9jbGFzc19saXN0PWZvY3VzJmNvbm5lY3Rpb25fZGF0YT1uYW1lJTNEWUo='